import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { BeliefBreak } from "@/components/site/BeliefBreak";
import { Story } from "@/components/site/Story";
import { Method } from "@/components/site/Method";
import { Proof } from "@/components/site/Proof";
import { Qualification } from "@/components/site/Qualification";
import { Offer } from "@/components/site/Offer";
import { FinalCta, SiteFooter } from "@/components/site/FinalCta";

const TITLE = "Matheus Freitas | Método Reset Metabólico";
const DESCRIPTION =
  "Protocolo privado de 6 meses para reprogramar o metabolismo: desinflamar, destravar a queima e sustentar performance. Acesso por aplicação.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const JSON_LD = {
  "@context": "https://schema.org",
  "@type": "Person",
  name: "Matheus Freitas",
  jobTitle: "Reprogramador de metabolismo",
  description: DESCRIPTION,
  knowsAbout: ["Metabolismo", "Performance", "Reprogramação metabólica"],
};

function Index() {
  return (
    <div id="top" className="relative min-h-screen overflow-x-hidden bg-background">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(JSON_LD) }}
      />
      <Nav />
      <main>
        <Hero />
        <BeliefBreak />
        <Story />
        <Method />
        <Proof />
        <Qualification />
        <Offer />
        <FinalCta />
      </main>
      <SiteFooter />
    </div>
  );
}
