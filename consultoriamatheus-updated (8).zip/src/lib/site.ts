// Ajuste aqui o número de WhatsApp (formato internacional, só dígitos).
export const WHATSAPP_NUMBER = "5567991272121";

export const WHATSAPP_MESSAGE =
  "Olá Matheus, quero aplicar para o Método Reset Metabólico.";

export const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
  WHATSAPP_MESSAGE,
)}`;
