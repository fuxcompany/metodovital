import { Counter, Eyebrow, Reveal, SectionShell } from "./primitives";

const STATS = [
  { to: 152, suffix: "+", label: "Pessoas reprogramadas" },
  { to: 6, suffix: " meses", label: "Duração do protocolo" },
  { to: 12, suffix: " anos", label: "Dentro do alto rendimento" },
  { to: 94, suffix: "%", label: "Permanência no programa" },
];

const RESULT_PHOTOS = Array.from(
  { length: 11 },
  (_, i) => `/images/resultados/resultado-${String(i + 1).padStart(2, "0")}.jpg`,
);

const TESTIMONIALS = [
  {
    quote:
      "Passei anos alternando entre dieta e culpa. O inchaço nunca saía de vez, só mudava de semana. Em menos de 6 meses ele sumiu, e pela primeira vez o resultado ficou. Não foi dieta. Foi entender por que meu corpo vivia inflamado.",
    name: "Sophia Rigoleto",
    detail: "Reset Metabólico · Desinflamação",
  },
  {
    quote:
      "Eu já tinha feito todo tipo de dieta. Emagrecia, engordava, e cada ciclo me deixava mais desconfiada de mim mesma. O que mudou aqui foi entender que o problema nunca foi falta de disciplina, era falta de estratégia. Hoje eu como sem medo e mantenho o corpo sem sofrer.",
    name: "Sabrina Trindade",
    detail: "Performance Sustentada",
  },
  {
    quote:
      "Eu achava que precisava de duas horas por dia pra isso dar certo. Achei que não ia caber na minha rotina de trabalho e filhos. A primeira coisa que mudei levou menos de 20 minutos pela manhã, e foi a que mais mudou meu dia. O resto foi se encaixando.",
    name: "Renato Vicente",
    detail: "Rotina Matinal",
  },
  {
    quote:
      "Com a idade eu aceitei que seria assim: cansada, retendo líquido, com fome fora de hora. Meus exames até davam 'normal'. O que ninguém olhava era o conjunto. Quando reorganizaram meu ritmo, sono, alimentação, rotina, meu corpo voltou a responder. Eu não precisava de mais força de vontade. Precisava de direção.",
    name: "Andréa de Fátima",
    detail: "Reset Metabólico · Reset Hormonal",
  },
  {
    quote:
      "O que me convenceu não foi a promessa. Foi o começo: antes de qualquer plano, ele mediu tudo. Exames, rotina, histórico, comportamento. Eu nunca tinha feito parte de um processo que começou me entendendo antes de me prescrever. A partir daí, eu soube que aquilo não era receita de internet.",
    name: "Lucas Alonso",
    detail: "Diagnóstico Metabólico",
  },
];

export function Proof() {
  return (
    <SectionShell id="resultados">
      <Reveal>
        <Eyebrow>04 · Resultado</Eyebrow>
        <h2 className="mt-6 max-w-2xl font-display text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02]">
          O método não promete. Ele <span className="text-gold-gradient">repete</span>.
        </h2>
      </Reveal>

      <div className="mt-14 grid grid-cols-2 gap-px border border-border bg-border md:grid-cols-4">
        {STATS.map((s, i) => (
          <Reveal key={s.label} delay={0.06 * i} y={16}>
            <div className="h-full bg-background p-7">
              <p className="font-display text-4xl font-extrabold text-gold md:text-5xl">
                <Counter to={s.to} suffix={s.suffix} />
              </p>
              <p className="mt-3 text-xs uppercase tracking-[0.18em] text-muted-foreground">
                {s.label}
              </p>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {TESTIMONIALS.map((t, i) => (
          <Reveal key={t.quote} delay={0.08 * i}>
            <figure className="glass flex h-full flex-col justify-between p-7">
              <blockquote className="text-lg leading-relaxed">“{t.quote}”</blockquote>
              <figcaption className="mt-8">
                <p className="text-sm font-semibold">{t.name}</p>
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  {t.detail}
                </p>
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>

      <div className="mt-16">
        <p className="eyebrow">Antes · Depois</p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {RESULT_PHOTOS.map((src, i) => (
            <Reveal key={src} delay={0.05 * i} y={16}>
              <div className="relative aspect-[3/4] overflow-hidden border border-border bg-navy">
                <img
                  src={src}
                  alt="Resultado real de aluno do Método Vital, antes e depois"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </SectionShell>
  );
}
