import { CtaButton, Eyebrow, Reveal, SectionShell } from "./primitives";

const INCLUDES = [
  {
    title: "Protocolo individual de 6 meses",
    desc: "Sequência completa dos 5 pilares, ajustada ao seu ponto de partida metabólico.",
  },
  {
    title: "Ajustes quinzenais",
    desc: "O protocolo é recalibrado conforme o corpo responde. Nada é entregue e esquecido.",
  },
  {
    title: "Direcionamento de rotina",
    desc: "Sono, luz, treino, hidratação e estresse tratados como variáveis do resultado.",
  },
  {
    title: "Canal direto com o Matheus",
    desc: "Suporte contínuo durante todo o programa, sem intermediário.",
  },
  {
    title: "Painel de marcos",
    desc: "Medidas, sinais clínicos e performance acompanhados mês a mês.",
  },
  {
    title: "Fase de consolidação",
    desc: "Os dois últimos meses existem para o resultado permanecer sem o protocolo ativo.",
  },
];

export function Offer() {
  return (
    <SectionShell id="programa">
      <div className="grid gap-14 lg:grid-cols-[1fr_1.1fr]">
        <Reveal>
          <Eyebrow>06 · Programa</Eyebrow>
          <h2 className="mt-6 font-display text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02]">
            Acompanhamento Reset Metabólico
          </h2>
          <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
            Não é consulta. É um programa fechado de seis meses em que seu metabolismo é
            diagnosticado, desinflamado, reprogramado e consolidado, com acompanhamento direto do
            começo ao fim.
          </p>
          <div className="mt-10 glass p-7">
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              Formato
            </p>
            <p className="mt-3 font-display text-xl font-bold">
              Individual · 6 meses · turmas privadas
            </p>
            <div className="hairline my-6" />
            <p className="text-sm leading-relaxed text-muted-foreground">
              O acesso acontece por processo de aplicação. Cada ciclo abre um número limitado de
              vagas para preservar a profundidade do acompanhamento.
            </p>
          </div>
          <CtaButton className="mt-8">Quero aplicar</CtaButton>
        </Reveal>

        <div className="grid gap-px border border-border bg-border sm:grid-cols-2">
          {INCLUDES.map((item, i) => (
            <Reveal key={item.title} delay={0.05 * i} y={16}>
              <div className="h-full bg-background p-7 transition-colors hover:bg-navy/50">
                <span className="font-mono text-[10px] text-gold">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-3 font-display text-base font-bold">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </SectionShell>
  );
}
