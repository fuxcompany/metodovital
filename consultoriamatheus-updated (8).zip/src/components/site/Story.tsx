import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { Eyebrow, Reveal, SectionShell } from "./primitives";

const CHAPTERS = [
  {
    marker: "O ATLETA",
    title: "Performance era obrigação, não estética",
    text: "Anos de rotina de alto rendimento: treino, recuperação, sono e alimentação medidos como variáveis de um sistema. Nada era feito por moda, era feito porque o corpo precisava responder no dia da competição.",
  },
  {
    marker: "A FRATURA",
    title: "O corpo parou de responder ao que sempre funcionou",
    text: "Mesma disciplina, resultado invertido: inchaço, energia baixa, gordura teimosa. Foi ali que ficou claro que o problema não era esforço, era programação metabólica.",
  },
  {
    marker: "A OBSESSÃO",
    title: "Estudar o metabolismo como se estuda um adversário",
    text: "Fisiologia, hormônios, inflamação, ritmo circadiano, carga de treino. Cada protocolo testado primeiro no próprio corpo, depois em atletas, depois em pessoas comuns com rotina real.",
  },
  {
    marker: "O MÉTODO",
    title: "Reset Metabólico nasce como protocolo, não como dieta",
    text: "Uma sequência de 6 meses que corrige o ambiente interno antes de exigir performance. Reprodutível, mensurável e independente de força de vontade.",
  },
];

export function Story() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start center", "end center"] });
  const height = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  return (
    <SectionShell id="historia">
      <Reveal>
        <Eyebrow>02 · Origem</Eyebrow>
        <h2 className="mt-6 max-w-2xl font-display text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02]">
          O método não veio de um consultório. Veio de uma <span className="text-gold-gradient">quadra</span>.
        </h2>
      </Reveal>

      <div ref={ref} className="mt-20 grid gap-12 md:grid-cols-[0.85fr_1.15fr]">
        <div className="md:sticky md:top-24 md:h-fit">
          <div className="glass relative aspect-[4/5] overflow-hidden">
            <img
              src="/images/matheus-foto.jpg"
              alt="Matheus Freitas"
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div
              className="absolute -bottom-20 -right-20 size-72 rounded-full bg-gold/15 blur-[90px]"
              aria-hidden
            />
            <div className="relative flex h-full flex-col justify-between p-8">
              <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground drop-shadow">
                Arquivo pessoal
              </span>
            </div>
          </div>
        </div>

        <div className="relative pl-8">
          <div className="absolute left-0 top-0 h-full w-px bg-border" aria-hidden />
          <motion.div
            style={{ height }}
            className="absolute left-0 top-0 w-px bg-gold"
            aria-hidden
          />
          <div className="space-y-16">
            {CHAPTERS.map((c, i) => (
              <Reveal key={c.marker} delay={0.05 * i}>
                <div className="relative">
                  <span
                    className="absolute -left-[2.05rem] top-2 size-2 rounded-full bg-gold"
                    aria-hidden
                  />
                  <span className="eyebrow">{c.marker}</span>
                  <h3 className="mt-3 font-display text-2xl font-bold leading-tight">{c.title}</h3>
                  <p className="mt-3 leading-relaxed text-muted-foreground">{c.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </SectionShell>
  );
}
