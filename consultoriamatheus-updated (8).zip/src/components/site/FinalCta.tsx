import { Counter, CtaButton, Reveal } from "./primitives";

const STEPS = [
  { n: "01", label: "Aplicação", desc: "Você envia seu contexto e histórico." },
  { n: "02", label: "Análise", desc: "O caso é avaliado para ver se o protocolo se aplica." },
  { n: "03", label: "Convite", desc: "Aprovado, você recebe a vaga do ciclo." },
];

export function FinalCta() {
  return (
    <section id="aplicar" className="relative overflow-hidden border-t border-border px-5 py-28 sm:px-8 md:py-36">
      <div className="grid-tech absolute inset-0 opacity-50" aria-hidden />
      <div
        className="absolute bottom-[-12rem] left-1/2 size-[40rem] -translate-x-1/2 rounded-full bg-gold/12 blur-[150px]"
        aria-hidden
      />
      <div className="relative mx-auto max-w-4xl text-center">
        <Reveal>
          <p className="eyebrow">Ciclo atual · vagas limitadas</p>
          <h2 className="mt-7 font-display text-[clamp(2.2rem,7vw,5rem)] font-extrabold leading-[0.98]">
            Restam <span className="text-gold-gradient"><Counter to={7} /></span> vagas neste ciclo.
          </h2>
          <p className="mx-auto mt-7 max-w-xl text-lg leading-relaxed text-muted-foreground">
            O acesso é por aplicação. Se o seu caso fizer sentido para o Reset Metabólico, você
            recebe o convite para entrar no ciclo.
          </p>
          <div className="mt-10 flex justify-center">
            <CtaButton>Iniciar aplicação</CtaButton>
          </div>
        </Reveal>

        <div className="mt-20 grid gap-px border border-border bg-border sm:grid-cols-3">
          {STEPS.map((s, i) => (
            <Reveal key={s.n} delay={0.07 * i} y={16}>
              <div className="h-full bg-background p-7 text-left">
                <span className="font-display text-3xl font-extrabold text-gold/30">{s.n}</span>
                <p className="mt-3 font-display font-bold">{s.label}</p>
                <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border px-5 py-10 sm:px-8">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <div
              className="absolute inset-0 -z-10 scale-125 rounded-full bg-gold/25 blur-md"
              aria-hidden
            />
            <img src="/images/logo-mf.png" alt="Matheus Freitas" className="relative h-8 w-auto" />
          </div>
          <div>
            <p className="font-display font-bold">Matheus Freitas</p>
            <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
              Criador do Método Reset Metabólico
            </p>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Reset Metabólico. Conteúdo educativo, não substitui
          avaliação médica.
        </p>
      </div>
    </footer>
  );
}
