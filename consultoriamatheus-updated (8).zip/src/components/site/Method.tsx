import { motion } from "motion/react";
import { Eyebrow, Reveal, SectionShell } from "./primitives";

const PILLARS = [
  {
    n: "01",
    title: "Diagnóstico Metabólico",
    desc: "Você não muda o que não mede. Antes de qualquer estratégia, um mapeamento completo do seu ponto de partida. Não existe rota sem origem.",
  },
  {
    n: "02",
    title: "Rotina Matinal",
    desc: "Seu corpo não acorda pronto, ele é ligado. Os primeiros 30 minutos do dia preparam cada sistema para operar. Você não entra no dia, você liga o corpo e o dia entra em você.",
  },
  {
    n: "03",
    title: "Reset Metabólico",
    desc: "Seu metabolismo não está lento, está confuso. O método reorganiza sinais, hormônios e inflamação silenciosa em três camadas. Não é restrição, é reorganização.",
  },
  {
    n: "04",
    title: "Hábitos-Chave",
    desc: "A transformação não acontece no que você faz por uma hora, acontece no que repete todos os dias. O que você faz entre as refeições pesa tanto quanto o que coloca nelas.",
  },
  {
    n: "05",
    title: "Performance Sustentada",
    desc: "O método só funciona se ele acabar. O que foi construído vira comportamento automático, sem efeito sanfona e sem depender de força de vontade.",
  },
];

export function Method() {
  return (
    <SectionShell id="metodo" className="border-y border-border bg-navy-deep">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <Reveal>
          <Eyebrow>03 · O protocolo</Eyebrow>
          <h2 className="mt-6 max-w-xl font-display text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02]">
            Método Vital · Os 5 Pilares
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="glass px-6 py-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              Duração
            </p>
            <p className="font-display text-2xl font-bold text-gold">6 meses · 5 pilares</p>
          </div>
        </Reveal>
      </div>

      <div className="mt-16 space-y-px">
        {PILLARS.map((p, i) => (
          <Reveal key={p.n} delay={0.05 * i} y={20}>
            <motion.div
              whileHover={{ x: 8 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="group relative grid gap-4 border border-border bg-navy/50 p-7 md:grid-cols-[auto_1fr_1.2fr] md:items-center md:gap-10 md:p-9"
            >
              <span className="font-display text-5xl font-extrabold text-gold/25 transition-colors duration-300 group-hover:text-gold md:text-6xl">
                {p.n}
              </span>
              <h3 className="font-display text-xl font-bold leading-tight md:text-2xl">
                {p.title}
              </h3>
              <p className="leading-relaxed text-muted-foreground">{p.desc}</p>
              <span
                className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-gold transition-transform duration-500 group-hover:scale-x-100"
                aria-hidden
              />
            </motion.div>
          </Reveal>
        ))}
      </div>
    </SectionShell>
  );
}
