import { motion, useScroll, useMotionValueEvent } from "motion/react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { whatsappUrl } from "@/lib/site";

const LINKS = [
  { href: "#metodo", label: "Método" },
  { href: "#resultados", label: "Resultados" },
  { href: "#programa", label: "Programa" },
];

export function Nav() {
  const { scrollY } = useScroll();
  const [solid, setSolid] = useState(false);
  useMotionValueEvent(scrollY, "change", (v) => setSolid(v > 40));

  return (
    <motion.nav
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.2 }}
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        solid ? "border-b border-border bg-background/80 backdrop-blur-xl" : "",
      )}
    >
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 sm:px-8">
        <a href="#top" className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <div
              className="absolute inset-0 -z-10 scale-125 rounded-full bg-gold/25 blur-md"
              aria-hidden
            />
            <img src="/images/logo-mf.png" alt="Matheus Freitas" className="relative h-9 w-auto" />
          </div>
          <span className="hidden font-display text-sm font-bold tracking-tight sm:inline">
            MATHEUS <span className="text-gold">FREITAS</span>
          </span>
        </a>
        <div className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-xs uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:text-gold"
            >
              {l.label}
            </a>
          ))}
        </div>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="border border-gold/40 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-gold transition-colors hover:bg-gold hover:text-primary-foreground"
        >
          Aplicar
        </a>
      </div>
    </motion.nav>
  );
}
