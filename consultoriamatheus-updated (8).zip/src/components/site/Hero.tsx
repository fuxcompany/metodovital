import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { CtaButton } from "./primitives";

const LINES = ["Seu metabolismo", "não está quebrado.", "Está mal programado."];

export function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 140]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <header
      ref={ref}
      className="relative flex min-h-[100svh] items-center overflow-hidden px-5 pt-28 pb-20 sm:px-8"
    >
      <div className="grid-tech absolute inset-0 opacity-60" aria-hidden />
      <div
        className="absolute -top-40 left-1/2 size-[38rem] -translate-x-1/2 rounded-full bg-gold/12 blur-[140px]"
        aria-hidden
      />
      <div
        className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-background to-transparent"
        aria-hidden
      />

      <motion.div style={{ y, opacity }} className="relative mx-auto w-full max-w-6xl">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="mb-10 flex items-center gap-3"
        >
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-gold/70" />
            <span className="relative inline-flex size-2 rounded-full bg-gold" />
          </span>
          <span className="eyebrow">Protocolo privado · 6 meses</span>
        </motion.div>

        <h1 className="font-display text-[clamp(2.6rem,9vw,7rem)] font-extrabold leading-[0.94]">
          {LINES.map((line, i) => (
            <span key={line} className="block overflow-hidden">
              <motion.span
                className={i === 2 ? "block text-gold-gradient" : "block"}
                initial={{ y: "110%" }}
                animate={{ y: 0 }}
                transition={{ duration: 1, delay: 0.15 * i, ease: [0.16, 1, 0.3, 1] }}
              >
                {line}
              </motion.span>
            </span>
          ))}
        </h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.7 }}
          className="mt-10 flex flex-col gap-8 md:flex-row md:items-end md:justify-between"
        >
          <div className="max-w-md">
            <div className="hairline mb-5 w-32" />
            <p className="font-display text-lg font-semibold tracking-tight">Matheus Freitas</p>
            <p className="mt-1 text-sm uppercase tracking-[0.22em] text-muted-foreground">
              Criador do Método Reset Metabólico
            </p>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              Ex-atleta. Reprogramador de metabolismo. Não trato sintoma com dieta, reescrevo o
              sistema que decide como seu corpo queima, inflama e performa.
            </p>
          </div>
          <CtaButton>Aplicar para o protocolo</CtaButton>
        </motion.div>
      </motion.div>

      <motion.div
        aria-hidden
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 sm:flex"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
          Role
        </span>
        <motion.span
          animate={{ scaleY: [0.2, 1, 0.2], originY: 0 }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="h-12 w-px bg-gold/70"
        />
      </motion.div>
    </header>
  );
}
