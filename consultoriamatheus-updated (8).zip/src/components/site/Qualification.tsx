import { Check, X } from "lucide-react";
import { Eyebrow, Reveal, SectionShell } from "./primitives";

const FOR = [
  "Já tentou dieta, treino e disciplina, e o corpo não respondeu",
  "Convive com inchaço, retenção, cansaço e inflamação crônica",
  "Quer um protocolo de 6 meses, com processo e acompanhamento",
  "Está disposto a mudar rotina, sono e comportamento, não só cardápio",
  "Busca resultado permanente, não perda rápida de peso",
];

const NOT_FOR = [
  "Quer fórmula mágica ou resultado em 15 dias",
  "Procura só um plano alimentar em PDF",
  "Não pretende seguir o protocolo por 6 meses",
  "Espera consulta pontual em vez de acompanhamento",
  "Não está disposto a rever hábitos além da alimentação",
];

export function Qualification() {
  return (
    <SectionShell id="qualificacao" className="border-y border-border bg-navy-deep">
      <Reveal>
        <Eyebrow>05 · Filtro</Eyebrow>
        <h2 className="mt-6 max-w-2xl font-display text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02]">
          O protocolo não é para todo mundo, e isso é <span className="text-gold-gradient">proposital</span>.
        </h2>
      </Reveal>

      <div className="mt-14 grid gap-6 md:grid-cols-2">
        <Reveal>
          <div className="glass h-full border-gold/40 p-8">
            <p className="eyebrow">É para você se</p>
            <ul className="mt-7 space-y-5">
              {FOR.map((item) => (
                <li key={item} className="flex gap-4">
                  <Check className="mt-0.5 size-5 shrink-0 text-gold" aria-hidden />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <Reveal delay={0.12}>
          <div className="h-full border border-border bg-navy/30 p-8 opacity-70">
            <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-muted-foreground">
              Não é para você se
            </p>
            <ul className="mt-7 space-y-5">
              {NOT_FOR.map((item) => (
                <li key={item} className="flex gap-4 text-muted-foreground">
                  <X className="mt-0.5 size-5 shrink-0" aria-hidden />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </SectionShell>
  );
}
