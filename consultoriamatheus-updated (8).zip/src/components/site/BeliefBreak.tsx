import { Eyebrow, Reveal, SectionShell } from "./primitives";

const CONTRASTS = [
  { old: "Cortar calorias", nova: "Restaurar sinalização hormonal" },
  { old: "Mais treino, mais cardio", nova: "Estímulo certo na fase certa" },
  { old: "Dieta que você aguenta", nova: "Metabolismo que trabalha por você" },
];

export function BeliefBreak() {
  return (
    <SectionShell id="ruptura" className="border-y border-border bg-navy-deep">
      <div className="grid gap-14 md:grid-cols-[0.9fr_1.1fr]">
        <Reveal>
          <Eyebrow>01 · Quebra de crença</Eyebrow>
          <h2 className="mt-6 font-display text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[1.02]">
            Nutrição tradicional falha porque trata{" "}
            <span className="text-muted-foreground line-through decoration-gold/60">o prato</span>,
            e o problema está no <span className="text-gold-gradient">sistema</span>.
          </h2>
        </Reveal>

        <Reveal delay={0.15}>
          <p className="text-lg leading-relaxed text-muted-foreground">
            Você já fez dieta. Já emagreceu. Já voltou. Isso não é falta de disciplina, é um
            metabolismo rodando um código antigo: inflamação crônica, retenção, cortisol alto,
            insulina instável, sono ruim. Nenhuma planilha de calorias reescreve esse código.
          </p>
          <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
            Reprogramação metabólica é outro jogo: ajustar as variáveis que comandam o corpo, em
            sequência, até que queimar gordura, desinchar e ter energia deixem de ser esforço e
            passem a ser comportamento padrão.
          </p>

          <div className="mt-10 space-y-px overflow-hidden border border-border">
            {CONTRASTS.map((c, i) => (
              <Reveal key={c.old} delay={0.1 * i} y={16}>
                <div className="grid grid-cols-2 gap-4 bg-navy/60 p-5 transition-colors hover:bg-navy">
                  <span className="text-sm text-muted-foreground line-through">{c.old}</span>
                  <span className="text-sm font-semibold text-foreground">{c.nova}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </Reveal>
      </div>
    </SectionShell>
  );
}
