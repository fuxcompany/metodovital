# Matheus Freitas — Método Reset Metabólico

Landing page única, em pt-BR, mobile-first, construída para autoridade e conversão. Navy #1C2A38 como base, Gold #D4AF37 como destaque, branco e preto para contraste. Tipografia editorial (serifada de peso para títulos + sans geométrica para texto), nada de estética "fitness casual".

## Decisões já definidas

- CTA final e todos os CTAs intermediários levam para o WhatsApp (número placeholder até você enviar o seu).
- Contador principal: 152+ pessoas reprogramadas. Demais números como placeholders editáveis.
- Método: programa de 6 meses, 5 pilares (nomes provisórios até você enviar os definitivos).
- Imagens: espaços preparados com tratamento visual (grão, gradiente navy/gold, molduras) para receber as fotos reais depois.

## Seções

1. **Hero de ruptura** — manifesto em tipografia gigante ("Seu metabolismo não está quebrado. Está mal programado."), nome + "Criador do Método Reset Metabólico" em caixa alta com filete dourado. Fundo navy com textura, revelação de texto por linha e indicador de scroll animado.
2. **Quebra de crença** — bloco curto e afiado em contraste: "dieta" riscada vs. "reprogramação", com transição de cor de fundo ao entrar na viewport.
3. **História do atleta** — scroll storytelling: coluna de texto que avança enquanto uma imagem/número fica fixo (sticky), marcos em linha do tempo dourada.
4. **O Método** — protocolo proprietário: 5 pilares numerados (01–05) em cards diagonais/assimétricos com numeração dourada em escala grande, faixa "Programa de 6 meses" atravessando a seção.
5. **Prova social** — contadores animados (152+ reprogramados, 6 meses de protocolo, anos de método, taxa de adesão), depoimentos em carrossel e grid de antes/depois com placeholders.
6. **Qualificação** — duas colunas em oposição visual: "É para você" (dourado) x "Não é para você" (esmaecido), reforçando filtro e exclusividade.
7. **Oferta** — o acompanhamento apresentado como Protocolo/Programa: o que inclui, formato dos 6 meses, entregas. Sem a palavra "consulta" em nenhum lugar.
8. **CTA final** — vagas limitadas + processo de aplicação, contador de vagas, botão para WhatsApp com mensagem pré-preenchida.

## Detalhes técnicos

- Rota única em `src/routes/index.tsx` substituindo o placeholder, com componentes por seção em `src/components/`.
- Tokens de cor, tipografia, sombras e gradientes definidos em `src/styles.css` (`@theme inline` + `:root`), sem cores hardcoded nos componentes.
- Fontes carregadas via `<link>` no `__root.tsx`.
- Animações com Motion for React: reveal on scroll, parallax leve, sticky storytelling, contadores animados por IntersectionObserver, microinterações de hover em botões e cards. `prefers-reduced-motion` respeitado.
- Componentes shadcn/ui (button, accordion, carousel) reestilizados com variantes premium próprias — nada com aparência padrão.
- SEO: `head()` na rota com title, description, og e twitter próprios; H1 único; alt em imagens; JSON-LD de Person/Service.
- Sem backend: o CTA é link direto para WhatsApp (`wa.me`), com número em constante única fácil de trocar.

## O que preciso de você depois

Fotos do Matheus e dos antes/depois, número de WhatsApp, nomes definitivos dos 5 pilares e depoimentos reais.
