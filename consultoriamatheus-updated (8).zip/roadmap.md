# Roadmap

- [x] Instalar Motion
- [x] Design system navy/gold futurista em src/styles.css + fontes no __root
- [x] Seções: Hero, Quebra de crença, História, Método (5 pilares), Prova social, Qualificação, Oferta, CTA final
- [x] Estética futurista inspirada em prism-gr8r.framer.ai (glass, grid, glow, mono labels)
- [x] CTA WhatsApp + SEO/JSON-LD

## Pendente (aguardando conteúdo do cliente)
- Número real de WhatsApp (src/lib/site.ts)
- Fotos do Matheus e antes/depois
- Nomes definitivos dos 5 pilares e depoimentos reais
